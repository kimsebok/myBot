# import os
# from os import pathsep
# from ament_index_python.packages import get_package_share_directory, get_package_prefix

# from launch import LaunchDescription
# from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, SetEnvironmentVariable
# from launch.substitutions import Command, LaunchConfiguration
# from launch.launch_description_sources import PythonLaunchDescriptionSource

# from launch_ros.actions import Node
# from launch_ros.parameter_descriptions import ParameterValue

import os
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, ExecuteProcess, IncludeLaunchDescription
from launch.substitutions import LaunchConfiguration, Command, PathJoinSubstitution
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare
from launch_ros.actions import ComposableNodeContainer
from launch_ros.descriptions import ComposableNode


def generate_launch_description():
    # bumperbot_description = get_package_share_directory("mybot_description")
    # bumperbot_description_prefix = get_package_prefix("mybot_description")
    # gazebo_ros_dir = get_package_share_directory("gazebo_ros")

    # model_arg = DeclareLaunchArgument(name="model", default_value=os.path.join(
    #                                     bumperbot_description, "urdf", "robot.urdf.xacro"
    #                                     ),
    #                                   description="Absolute path to robot urdf file"
    # )

    # model_path = os.path.join(bumperbot_description, "models")
    # model_path += pathsep + os.path.join(bumperbot_description_prefix, "share")

    # env_var = SetEnvironmentVariable("GAZEBO_MODEL_PATH", model_path)

    # robot_description = ParameterValue(Command(["xacro ", LaunchConfiguration("model")]),
    #                                    value_type=str)

    # robot_state_publisher_node = Node(
    #     package="robot_state_publisher",
    #     executable="robot_state_publisher",
    #     parameters=[{"robot_description": robot_description}]
    # )

    # start_gazebo_server = IncludeLaunchDescription(
    #     PythonLaunchDescriptionSource(
    #         os.path.join(gazebo_ros_dir, "launch", "gzserver.launch.py")
    #     )
    # )

    # start_gazebo_client = IncludeLaunchDescription(
    #     PythonLaunchDescriptionSource(
    #         os.path.join(gazebo_ros_dir, "launch", "gzclient.launch.py")
    #     )
    # )

    # spawn_robot = Node(package="gazebo_ros", executable="spawn_entity.py",
    #                     arguments=["-entity", "mybot",
    #                                "-topic", "robot_description",
    #                               ],
    #                     output="screen"
    # )

    

    use_sim_time = True

    ekf_config_path = PathJoinSubstitution(
        [FindPackageShare("mtbot_description"), "config", "ekf.yaml"]
    )

    world_path = PathJoinSubstitution(
        [FindPackageShare("mybot_description"), "worlds", "playground.world"]
    )

    description_launch_path = PathJoinSubstitution(
        [FindPackageShare('mybot_description'), 'launch', 'rviz.launch.py']
    )


    return LaunchDescription([
        
        # env_var,
        # model_arg,
        # start_gazebo_server,
        # start_gazebo_client,
        # robot_state_publisher_node,
        # spawn_robot


        DeclareLaunchArgument(
            name='world', 
            default_value=world_path,
            description='Gazebo world'
        ),

        DeclareLaunchArgument(
            name='spawn_x', 
            default_value='0.0',
            description='Robot spawn position in X axis'
        ),

        DeclareLaunchArgument(
            name='spawn_y', 
            default_value='0.0',
            description='Robot spawn position in Y axis'
        ),

        DeclareLaunchArgument(
            name='spawn_z', 
            default_value='0.0',
            description='Robot spawn position in Z axis'
        ),
            
        DeclareLaunchArgument(
            name='spawn_yaw', 
            default_value='0.0',
            description='Robot spawn heading'
        ),

        ExecuteProcess(
            cmd=['gazebo', '--verbose', '-s', 'libgazebo_ros_factory.so',  '-s', 'libgazebo_ros_init.so', LaunchConfiguration('world')],
            output='screen'
        ),

        Node(
            package='gazebo_ros',
            executable='spawn_entity.py',
            name='urdf_spawner',
            output='screen',
            arguments=[
                '-topic', 'robot_description', 
                '-entity', 'linorobot2', 
                '-x', LaunchConfiguration('spawn_x'),
                '-y', LaunchConfiguration('spawn_y'),
                '-z', LaunchConfiguration('spawn_z'),
                '-Y', LaunchConfiguration('spawn_yaw'),
            ]
        ),

        Node(
            package='mybot_description',
            executable='command_timeout.py',
            name='command_timeout'
        ),

        Node(
            package='robot_localization',
            executable='ekf_node',
            name='ekf_filter_node',
            output='screen',
            parameters=[
                {'use_sim_time': use_sim_time}, 
                ekf_config_path
            ],
            remappings=[("odometry/filtered", "odom")]
        ),

        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(description_launch_path),
            launch_arguments={
                'use_sim_time': str(use_sim_time),
                'publish_joints': 'false',
            }.items()
        )
    ])